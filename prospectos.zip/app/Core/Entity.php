<?php

namespace Application\Core;

class Entity
{
}
