<?php

define('LANG', [
    'Welcome' => 'Bienvenido',
    'Hello' => 'Hola',
    'Subscribe' => 'Suscribir',
]);
