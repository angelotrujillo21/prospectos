<?php

define('LANG', [
    'Welcome' => 'Bienvenue',
    'Hello' => 'Bonjour',
    'Subscribe' => 'Souscrire',
]);
