<?php

define('LANG', [
    'Welcome' => 'Welcome',
    'Hello' => 'Hello',
    'Subscribe' => 'Subscribe',
]);
